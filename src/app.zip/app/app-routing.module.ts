import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';

import { AddNeedyPeopleComponent } from './add-needy-people/add-needy-people.component';
import { ViewRequestComponent } from './view-request/view-request.component';
import { ViewComponent } from './view/view.component';

const routes: Routes = [
  {path:'addneedypeople',component:AddNeedyPeopleComponent},
  {path:'viewall',component:ViewComponent},
  {path:'viewRequest',component:ViewRequestComponent}
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
