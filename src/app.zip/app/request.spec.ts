import { Request } from './request';

describe('Request', () => {
  it('should create an instance', () => {
    expect(new Request()).toBeTruthy();
  });
});
