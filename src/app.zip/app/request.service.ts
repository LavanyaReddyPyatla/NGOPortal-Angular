import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { HttpClient } from '@angular/common/http'

@Injectable({
  providedIn: 'root'
})
export class RequestService {

  constructor(private httpClient: HttpClient) { }

  public viewAll():Observable<any>{
    return this.httpClient.get("http://localhost:7071/requests");
  }
  public updateRequest(id: number,request: any):Observable<any>{
    return this.httpClient.put("http://localhost:7071/updatestatus/"+id
    ,request);
  }  

  

}
