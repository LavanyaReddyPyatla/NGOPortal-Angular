

export class NeedyPeople {

    needyPersonId!:number;
    needyPersonName!:string;
    phone!:string;
    familyIncome!:number;
    email!:string;
    password!:string;
    confirmpassword!:string;
    address!:Address;
    city!:string ;
    state!:string ;
    pin!:string ;
    landmark!:string;
} 

   export class Address{
    addressId!:number;
    city!:string ;
    state!:string ;
    pin!:string ;
    landmark!:string;
    
}