import { NeedyPeople } from "./needy-people";

export class Request {
    id!: number;
    title!: string;
    description!: string;
    amount!: number;
    status!:boolean;
}
