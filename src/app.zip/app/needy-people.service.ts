import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { NeedyPeople } from './needy-people';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class NeedyPeopleService {
  [x: string]: any;

  constructor(private http:HttpClient) { }

  public addneedypeople(needypeople:NeedyPeople):Observable<any>{
    console.log(needypeople);
    return this.http.post("http://localhost:7071/employee/addneedypeople",needypeople,{responseType:'text'});
  }

  public view():Observable<any>{
    return this.http.get("http://localhost:7071/employee/viewall");

  }

  updateNeedy(modify:NeedyPeople)
  {
    return this.http.put("http://localhost:7071/employee/update",modify,{responseType:'text'});
  }
}
