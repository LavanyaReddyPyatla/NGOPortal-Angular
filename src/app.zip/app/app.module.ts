import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { AddNeedyPeopleComponent } from './add-needy-people/add-needy-people.component';
import { FormsModule } from '@angular/forms';
import {HttpClient, HttpClientModule } from '@angular/common/http';
import { ViewComponent } from './view/view.component';

import { NeedyPeople } from './needy-people';
import { FilterPipe } from './filter.pipe';
import { ViewRequestComponent } from './view-request/view-request.component';


@NgModule({
  declarations: [
    AppComponent,
    AddNeedyPeopleComponent,
    ViewComponent,
    FilterPipe,
    ViewRequestComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    FormsModule,
    HttpClientModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
