import { NeedyPeople } from './needy-people';

describe('NeedyPeople', () => {
  it('should create an instance', () => {
    expect(new NeedyPeople()).toBeTruthy();
  });
});
