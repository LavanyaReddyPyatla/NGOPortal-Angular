import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { RequestService } from '../request.service';
import {Request} from '../request';
@Component({
  selector: 'app-view-request',
  templateUrl: './view-request.component.html',
  styleUrls: ['./view-request.component.css']
})
export class ViewRequestComponent implements OnInit {

  requests!:Request[];
  //modify=new Request();
  Approve:boolean=false;
  Reject:boolean=false;
  msg:string | undefined;
  errorMsg:string  | undefined;

  constructor(private requestService:RequestService , private route:ActivatedRoute) { }

  ngOnInit(): void {
    console.log("Am inside view component");
    this.requestService.viewAll().subscribe((data:Request[])=>this.requests=data);
    console.log(this.requests);
  }
  
  updateStatus(requestData: Request) {
    
    console.log(requestData);
    this.requestService.updateRequest(requestData.id, requestData).subscribe((res: any) => { console.log(res) })
    
  }

}
